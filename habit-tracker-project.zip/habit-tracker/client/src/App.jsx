import { useEffect, useState } from "react";
import {
  Activity, BarChart3, CalendarDays, Check, CheckCircle2, Circle,
  Droplets, Dumbbell, Leaf, Plus, Sparkles, Target, Trash2, BookOpen,
  Heart, Menu, X
} from "lucide-react";
import "./App.css";

const API = "http://localhost:5000/api";
const categoryIcons = {
  Health: Droplets,
  Fitness: Dumbbell,
  Learning: BookOpen,
  Mindfulness: Heart,
  Personal: Leaf
};

export default function App() {
  const [habits, setHabits] = useState([]);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Personal");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [mobileMenu, setMobileMenu] = useState(false);

  async function loadHabits() {
    try {
      const response = await fetch(`${API}/habits`);
      if (!response.ok) throw new Error("Could not load habits.");
      setHabits(await response.json());
      setError("");
    } catch {
      setError("Can't reach the backend. Start the server using the README instructions.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadHabits(); }, []);

  async function addHabit(event) {
    event.preventDefault();
    if (!name.trim()) return;
    try {
      const response = await fetch(`${API}/habits`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), category })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not add habit.");
      setHabits(previous => [data, ...previous]);
      setName("");
      setError("");
    } catch (err) { setError(err.message); }
  }

  async function toggleHabit(id) {
    try {
      const response = await fetch(`${API}/habits/${id}`, { method: "PATCH" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not update habit.");
      setHabits(previous => previous.map(habit => habit.id === id ? data : habit));
    } catch (err) { setError(err.message); }
  }

  async function deleteHabit(id) {
    try {
      const response = await fetch(`${API}/habits/${id}`, { method: "DELETE" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not delete habit.");
      setHabits(previous => previous.filter(habit => habit.id !== id));
    } catch (err) { setError(err.message); }
  }

  const completed = habits.filter(habit => habit.completed).length;
  const percentage = habits.length ? Math.round(completed / habits.length * 100) : 0;
  const date = new Date().toLocaleDateString("en-IN", {
    weekday: "short", day: "numeric", month: "short", year: "numeric"
  });

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand"><span className="brand-mark"><Leaf size={22} /></span> HabitFlow<span className="brand-dot">.</span></div>
        <div className="nav-caption">WORKSPACE</div>
        <div className="nav-item active"><BarChart3 size={18} /> Dashboard</div>
        <a className="nav-item" href="#habits" onClick={() => setMobileMenu(false)}><CheckCircle2 size={18} /> My Habits</a>
        <a className="nav-item" href="#progress" onClick={() => setMobileMenu(false)}><Activity size={18} /> Progress</a>
        <div className="sidebar-note">
          <div className="note-icon"><Sparkles size={19} /></div>
          <strong>Small steps, big changes.</strong>
          <p>Consistency is built one day at a time.</p>
        </div>
        <div className="sidebar-bottom"><span className="online-dot" /> Your growth space</div>
      </aside>

      {mobileMenu && <button className="scrim" onClick={() => setMobileMenu(false)} aria-label="Close menu" />}
      <main className="main-content">
        <header className="topbar">
          <button className="menu-button" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle menu">
            {mobileMenu ? <X size={21} /> : <Menu size={21} />}
          </button>
          <span className="topbar-label">YOUR PERSONAL GROWTH SPACE</span>
          <div className="profile-avatar">M</div>
        </header>

        <section className="welcome">
          <div>
            <p className="eyebrow">LET'S MAKE TODAY COUNT</p>
            <h1>Good things take <span>daily practice.</span> ✨</h1>
            <p className="welcome-subtitle">Show up for yourself. Every little win matters.</p>
          </div>
          <div className="date-pill"><CalendarDays size={16} /> {date}</div>
        </section>

        {error && <div className="error-banner" role="alert">{error}<button onClick={loadHabits}>Retry</button></div>}

        <section className="stats-grid" aria-label="Habit statistics">
          <article className="stat-card stat-green"><div className="stat-top"><span>Total habits</span><span className="stat-icon"><Leaf size={18} /></span></div><strong>{habits.length}</strong><small>Your goals, your journey</small></article>
          <article className="stat-card stat-purple"><div className="stat-top"><span>Completed</span><span className="stat-icon"><CheckCircle2 size={18} /></span></div><strong>{completed}</strong><small>Habits checked off</small></article>
          <article className="stat-card stat-peach"><div className="stat-top"><span>Remaining</span><span className="stat-icon"><Target size={18} /></span></div><strong>{habits.length - completed}</strong><small>One step at a time</small></article>
          <article className="stat-card stat-blue"><div className="stat-top"><span>Daily progress</span><span className="stat-icon"><Activity size={18} /></span></div><strong>{percentage}%</strong><small>Keep your momentum</small></article>
        </section>

        <section className="dashboard-grid">
          <article className="panel habits-panel" id="habits">
            <div className="panel-heading"><div><h2>Today's habits</h2><p>Make space for what matters.</p></div><span className="completion-pill">{completed}/{habits.length} done</span></div>
            {loading ? <div className="empty-state">Loading your habits…</div> : habits.length === 0 ? (
              <div className="empty-state"><div className="empty-illustration"><Leaf size={28} /></div><h3>Your journey starts here</h3><p>Add your first habit and start building a routine you love.</p></div>
            ) : (
              <div className="habit-list">{habits.map(habit => {
                const Icon = categoryIcons[habit.category] || Circle;
                return <div className={`habit-row ${habit.completed ? "habit-completed" : ""}`} key={habit.id}>
                  <button className={`habit-check ${habit.completed ? "is-checked" : ""}`} onClick={() => toggleHabit(habit.id)} aria-label={`${habit.completed ? "Mark incomplete" : "Complete"} ${habit.name}`}>
                    {habit.completed ? <Check size={16} /> : <Icon size={16} />}
                  </button>
                  <div className="habit-copy"><strong>{habit.name}</strong><span>{habit.category}</span></div>
                  <span className={`status-label ${habit.completed ? "status-done" : ""}`}>{habit.completed ? "Completed" : "In progress"}</span>
                  <button className="delete-button" onClick={() => deleteHabit(habit.id)} aria-label={`Delete ${habit.name}`} title="Delete habit"><Trash2 size={16} /></button>
                </div>;
              })}</div>
            )}
          </article>

          <div className="right-column">
            <article className="panel add-panel">
              <div className="form-title-icon"><Plus size={19} /></div>
              <h2>Create a habit</h2><p className="panel-subtitle">What would you like to work on?</p>
              <form onSubmit={addHabit}>
                <label htmlFor="habit-name">Habit name</label>
                <input id="habit-name" value={name} onChange={event => setName(event.target.value)} placeholder="e.g. Drink more water" maxLength={100} required />
                <label htmlFor="habit-category">Choose a category</label>
                <select id="habit-category" value={category} onChange={event => setCategory(event.target.value)}>
                  <option>Personal</option><option>Health</option><option>Learning</option><option>Fitness</option><option>Mindfulness</option>
                </select>
                <button className="primary-button" type="submit"><Plus size={17} /> Add my habit</button>
              </form>
            </article>

            <article className="panel progress-panel" id="progress">
              <div className="panel-heading"><div><h2>Your daily progress</h2><p>Celebrate every step forward.</p></div><span className="progress-sparkle"><Sparkles size={19} /></span></div>
              <div className="progress-ring" style={{ "--progress": `${percentage}%` }}><div className="progress-ring-inner"><strong>{percentage}%</strong><span>completed</span></div></div>
              <p className="progress-message">{percentage === 100 && habits.length > 0 ? "You did it! Every habit is complete. 🎉" : percentage >= 50 ? "You're building great momentum. Keep going!" : "Start small. Your future self will thank you."}</p>
            </article>
          </div>
        </section>
        <footer className="footer"><span>Made with <Heart size={13} fill="currentColor" /> for a better you</span><span>HABITFLOW © {new Date().getFullYear()}</span></footer>
      </main>
    </div>
  );
}
