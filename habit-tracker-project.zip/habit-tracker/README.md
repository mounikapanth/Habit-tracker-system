# Habit Tracker — Hackathon Prototype

A working local habit tracker built with React, Vite, Node.js, Express, and SQLite.

## Requirements
- Node.js (LTS recommended)
- npm

## 1. Install backend dependencies
Open a terminal in this folder:

```bash
cd server
npm install
```

## 2. Install frontend dependencies
Open a second terminal in the project root:

```bash
cd client
npm install
```

## 3. Start the backend
From the project root, in terminal 1:

```bash
cd server
npm run dev
```

Backend: http://localhost:5000

## 4. Start the frontend
In terminal 2, from the project root:

```bash
cd client
npm run dev
```

Open the local URL Vite prints, usually http://localhost:5173.

## Features
- Add habits and choose a category
- Mark habits complete/incomplete
- Delete habits
- Dashboard totals and completion percentage
- SQLite persistence

## API endpoints
- `GET /api/habits`
- `POST /api/habits`
- `PATCH /api/habits/:id`
- `DELETE /api/habits/:id`
- `GET /api/stats`

## Notes
This is a local hackathon starter prototype. It does not yet include user accounts, per-day completion history, reminders, or production deployment. The SQLite database file is created automatically when the backend starts.
